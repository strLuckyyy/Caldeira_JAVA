![thumbnail-Formação Java (2)](https://user-images.githubusercontent.com/66698429/226425694-5f585247-7b60-4db9-9815-d232ba775434.png)


# Java: aplicando a Orientação a Objetos

Projeto desenvolvido no segundo curso da nova formação Java da Alura


## 🔨 Objetivos do projeto

- Aplicar os conceitos de Orientação a Objetos no projeto ScreenMatch;
- Modelar as abstraçoes a aplicação através de classes, atributos e métodos; 
- Conhecer e utilizar herança como mecanismo de reaproveitamento de código;
- Trabalhar com polimorfismo para tornar o código do projeto mais flexível;
- Entender cmo utilizar interfaces para padronização de métodos.

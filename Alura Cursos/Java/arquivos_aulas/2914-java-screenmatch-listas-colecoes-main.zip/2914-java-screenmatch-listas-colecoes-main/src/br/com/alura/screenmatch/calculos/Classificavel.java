package br.com.alura.screenmatch.calculos;

public interface Classificavel {
    int getClassificacao();
}
